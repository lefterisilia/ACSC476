CREATE TABLE Portofolio (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            title VARCHAR(255) NOT NULL,
                            description TEXT NOT NULL,
                            image_source VARCHAR(255) NOT NULL,
                            category VARCHAR(50) NOT NULL
);

INSERT INTO Portofolio (title, description, image_source, category) VALUES
                                                                        ('App 1', 'Lorem ipsum, dolor sit amet consectetur', 'assets/img/portfolio/app-1.jpg', 'app'),
                                                                        ('Product 1', 'Lorem ipsum, dolor sit amet consectetur', 'assets/img/portfolio/product-1.jpg', 'product'),
                                                                        ('Branding 1', 'Lorem ipsum, dolor sit amet consectetur', 'assets/img/portfolio/branding-1.jpg', 'branding'),
                                                                        ('Books 1', 'Lorem ipsum, dolor sit amet consectetur', 'assets/img/portfolio/books-1.jpg', 'books'),
                                                                        ('App 2', 'Lorem ipsum, dolor sit amet consectetur', 'assets/img/portfolio/app-2.jpg', 'app'),
                                                                        ('Product 2', 'Lorem ipsum, dolor sit amet consectetur', 'assets/img/portfolio/product-2.jpg', 'product'),
                                                                        ('Branding 2', 'Lorem ipsum, dolor sit amet consectetur', 'assets/img/portfolio/branding-2.jpg', 'branding'),
                                                                        ('Books 2', 'Lorem ipsum, dolor sit amet consectetur', 'assets/img/portfolio/books-2.jpg', 'books'),
                                                                        ('App 3', 'Lorem ipsum, dolor sit amet consectetur', 'assets/img/portfolio/app-3.jpg', 'app'),
                                                                        ('Product 3', 'Lorem ipsum, dolor sit amet consectetur', 'assets/img/portfolio/product-3.jpg', 'product'),
                                                                        ('Branding 3', 'Lorem ipsum, dolor sit amet consectetur', 'assets/img/portfolio/branding-3.jpg', 'branding'),
                                                                        ('Books 3', 'Lorem ipsum, dolor sit amet consectetur', 'assets/img/portfolio/books-3.jpg', 'books');