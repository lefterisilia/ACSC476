<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection details
$server = "localhost";
$username = "root";
$password = "";
$dbname = "lab7";
$articles = [];

// Establish a connection to the MySQL database
$connection = mysqli_connect($server, $username, $password, $dbname);

// Check if the connection was successful
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// SQL query to fetch all records from the `portofolio` table
$query = "SELECT title, description, image_source,category FROM `portofolio`";
$result = mysqli_query($connection, $query);

// Check if the query execution was successful
if (!$result) {
    die("Query Error: " . mysqli_error($connection));
}

// Fetch data from the result and store it in the $articles array
while ($data = mysqli_fetch_array($result)) {
    $articles[] = $data;
}

// Close the database connection
mysqli_close($connection);

// Check if there are any articles to display
if (count($articles)) {
    // Loop through each article and generate HTML output
    foreach ($articles as $article) {
        echo '<div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-' . htmlspecialchars($article['category']) . '">' .
            '<div class="portfolio-content h-100">' .
            '<img src="' . htmlspecialchars($article['image_source']) . '" class="img-fluid" alt="">' .
            '<div class="portfolio-info">' .
            '<h4>' . htmlspecialchars($article['title']) . '</h4>' .
            '<p>' . htmlspecialchars($article['description']) . '</p>' .
            '<a href="' . htmlspecialchars($article['image_source']) . '" title="' . htmlspecialchars($article['title']) . '" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>' .
            '<a href="portfolio-details.php" title="More Details" class="details-link"><i class="bi bi-link-45deg"></i></a>' .
            '</div>' .
            '</div>' .
            '</div>';
    }
} else {
    // If no articles are found, display a message
    echo 'There are no articles here.';
}
?>